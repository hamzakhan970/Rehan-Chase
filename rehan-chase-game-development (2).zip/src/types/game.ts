export interface CharacterDef {
  id: 'hamza' | 'huzaifa' | 'muaviya';
  name: string;
  nickname: string;
  role: string;
  tagline: string;
  color: string;
  secondaryColor: string;
  avatarEmoji: string;
  speedBonus: number;
  magnetBonus: number;
  jumpBonus: number;
  description: string;
  unlockScore: number;
  outfit: {
    capColor: string;
    shirtColor: string;
    pantsColor: string;
    shoesColor: string;
  };
}

export const CHARACTERS: CharacterDef[] = [
  {
    id: 'hamza',
    name: 'Hamza',
    nickname: 'The Speedy Dash',
    role: 'Street Sprinter',
    tagline: 'Runs like lightning through Karachi streets!',
    color: '#3B82F6', // Blue
    secondaryColor: '#60A5FA',
    avatarEmoji: '⚡',
    speedBonus: 1.1,
    magnetBonus: 1.0,
    jumpBonus: 1.05,
    description: 'Hamza is nimble and quick on his feet. He turns lanes faster and has a slight jump advantage.',
    unlockScore: 0,
    outfit: {
      capColor: '#2563EB',
      shirtColor: '#3B82F6',
      pantsColor: '#1E293B',
      shoesColor: '#EF4444'
    }
  },
  {
    id: 'huzaifa',
    name: 'Huzaifa',
    nickname: 'The High Flyer',
    role: 'Parkour Ace',
    tagline: 'Defies gravity over barricades and police cruisers!',
    color: '#10B981', // Emerald
    secondaryColor: '#34D399',
    avatarEmoji: '🦘',
    speedBonus: 1.0,
    magnetBonus: 1.1,
    jumpBonus: 1.25,
    description: 'Huzaifa can leap high above tall train barriers and hover slightly longer in the air.',
    unlockScore: 1200,
    outfit: {
      capColor: '#059669',
      shirtColor: '#10B981',
      pantsColor: '#0F172A',
      shoesColor: '#F59E0B'
    }
  },
  {
    id: 'muaviya',
    name: 'Muaviya',
    nickname: 'The Coin Magnet',
    role: 'Tech Gizmo Master',
    tagline: 'Always equipped with magnetic swag and shield gadgets!',
    color: '#F59E0B', // Amber/Gold
    secondaryColor: '#FBBF24',
    avatarEmoji: '🧲',
    speedBonus: 1.0,
    magnetBonus: 1.4,
    jumpBonus: 1.0,
    description: 'Muaviya attracts coins from farther away and extended power-up durations.',
    unlockScore: 2500,
    outfit: {
      capColor: '#D97706',
      shirtColor: '#F59E0B',
      pantsColor: '#334155',
      shoesColor: '#8B5CF6'
    }
  }
];

export interface Obstacle {
  id: number;
  lane: number; // -1: left, 0: center, 1: right
  z: number; // distance ahead in virtual units (e.g. 500 down to 0)
  type: 'barrier_low' | 'barrier_high' | 'train' | 'police_car' | 'traffic_cone' | 'construction_barrier';
  width: number;
  height: number;
  passed?: boolean;
}

export interface Coin {
  id: number;
  lane: number;
  z: number;
  y: number; // height from ground (0 for ground, 40 for jumping arc)
  collected?: boolean;
}

export interface PowerUpItem {
  id: number;
  lane: number;
  z: number;
  type: 'magnet' | 'shield' | 'boost' | '2x';
  collected?: boolean;
}

export interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  color: string;
  size: number;
  alpha: number;
  life: number;
}
