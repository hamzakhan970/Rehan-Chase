import { CharacterDef, Obstacle, Coin, PowerUpItem, Particle } from '../types/game';

interface DrawSceneParams {
  ctx: CanvasRenderingContext2D;
  width: number;
  height: number;
  playerLane: number; // smooth float value
  targetLane: number;
  playerY: number;
  isJumping: boolean;
  isSliding: boolean;
  slideProgress: number; // 0 to 1
  character: CharacterDef;
  obstacles: Obstacle[];
  coins: Coin[];
  powerUps: PowerUpItem[];
  particles: Particle[];
  rehanDistance: number; // 0 to 100 (0 = right behind you!)
  rehanLane: number;
  gameTime: number;
  activeShield: boolean;
  activeMagnet: boolean;
  activeBoost: boolean;
  activeMultiplier: boolean;
}

export function drawRunnerScene(params: DrawSceneParams) {
  const {
    ctx,
    width,
    height,
    playerLane,
    playerY,
    isJumping,
    isSliding,
    character,
    obstacles,
    coins,
    powerUps,
    particles,
    rehanDistance,
    rehanLane,
    gameTime,
    activeShield,
    activeMagnet,
    activeBoost,
  } = params;

  ctx.clearRect(0, 0, width, height);

  // 1. Perspective Horizon & Vanishing Point
  const horizonY = height * 0.38;
  const vpX = width * 0.5;

  // Sky Gradient (Evening / Cyberpunk Sunset Subway Vibe)
  const skyGrad = ctx.createLinearGradient(0, 0, 0, horizonY);
  skyGrad.addColorStop(0, '#0F172A'); // deep navy
  skyGrad.addColorStop(0.5, '#312E81'); // indigo
  skyGrad.addColorStop(1, '#831843'); // sunset ruby
  ctx.fillStyle = skyGrad;
  ctx.fillRect(0, 0, width, horizonY);

  // Distant City Skyline & Billboards
  drawSkyline(ctx, width, horizonY, gameTime);

  // 2. Ground & Track
  const groundGrad = ctx.createLinearGradient(0, horizonY, 0, height);
  groundGrad.addColorStop(0, '#1E1B4B');
  groundGrad.addColorStop(0.2, '#18181B');
  groundGrad.addColorStop(1, '#09090B');
  ctx.fillStyle = groundGrad;
  ctx.fillRect(0, horizonY, width, height - horizonY);

  // Perspective Track coordinates
  const trackTopW = width * 0.28;
  const trackBotW = width * 0.96;
  const trackTopLeft = vpX - trackTopW / 2;
  const trackTopRight = vpX + trackTopW / 2;
  const trackBotLeft = vpX - trackBotW / 2;
  const trackBotRight = vpX + trackBotW / 2;

  // Roadbed
  ctx.beginPath();
  ctx.moveTo(trackTopLeft, horizonY);
  ctx.lineTo(trackTopRight, horizonY);
  ctx.lineTo(trackBotRight, height);
  ctx.lineTo(trackBotLeft, height);
  ctx.closePath();
  ctx.fillStyle = '#27272A';
  ctx.fill();

  // Outer Neon Curb / Guardrails
  ctx.strokeStyle = '#EC4899';
  ctx.lineWidth = 4;
  ctx.beginPath();
  ctx.moveTo(trackTopLeft, horizonY);
  ctx.lineTo(trackBotLeft, height);
  ctx.moveTo(trackTopRight, horizonY);
  ctx.lineTo(trackBotRight, height);
  ctx.stroke();

  // 3 Lanes Dividers (Lane -1, Lane 0, Lane 1)
  const laneLinesTop = [
    trackTopLeft + trackTopW * (1 / 3),
    trackTopLeft + trackTopW * (2 / 3),
  ];
  const laneLinesBot = [
    trackBotLeft + trackBotW * (1 / 3),
    trackBotLeft + trackBotW * (2 / 3),
  ];

  ctx.strokeStyle = '#FACC15';
  ctx.lineWidth = 3;
  ctx.setLineDash([20, 25]);
  ctx.lineDashOffset = -((gameTime * 350) % 45);

  for (let i = 0; i < 2; i++) {
    ctx.beginPath();
    ctx.moveTo(laneLinesTop[i], horizonY);
    ctx.lineTo(laneLinesBot[i], height);
    ctx.stroke();
  }
  ctx.setLineDash([]); // reset

  // Animated perspective rail ties (sleepers) moving towards camera
  const speed = activeBoost ? 1.8 : 1.0;
  const tieOffset = ((gameTime * 400 * speed) % 60) / 60;
  ctx.strokeStyle = 'rgba(255, 255, 255, 0.08)';
  ctx.lineWidth = 2;
  for (let t = 0; t < 12; t++) {
    const p = Math.pow((t + tieOffset) / 12, 2.2);
    const y = horizonY + (height - horizonY) * p;
    const leftX = trackTopLeft + (trackBotLeft - trackTopLeft) * p;
    const rightX = trackTopRight + (trackBotRight - trackTopRight) * p;

    ctx.beginPath();
    ctx.moveTo(leftX, y);
    ctx.lineTo(rightX, y);
    ctx.stroke();
  }

  // Projection helper for 3D elements
  // z: 600 (far) to 0 (close/past player)
  // lane: -1 (left), 0 (mid), 1 (right)
  const project = (lane: number, z: number, yOffset: number = 0) => {
    // clamp z
    const normZ = Math.max(0, Math.min(650, z));
    const factor = 1 - normZ / 650;
    const p = Math.pow(factor, 2.1); // depth curve

    const currentTrackW = trackTopW + (trackBotW - trackTopW) * p;
    const currentTrackLeft = trackTopLeft + (trackBotLeft - trackTopLeft) * p;
    const laneWidth = currentTrackW / 3;

    // lane -1 -> 0.5, lane 0 -> 1.5, lane 1 -> 2.5
    const laneX = currentTrackLeft + laneWidth * (lane + 1 + 0.5);
    const screenY = horizonY + (height - horizonY) * p - yOffset * (0.3 + 0.7 * p);
    const scale = 0.2 + 0.8 * p;

    return { x: laneX, y: screenY, scale, p };
  };

  // Sort objects by z in descending order (render farthest first)
  interface RenderableItem {
    type: 'obstacle' | 'coin' | 'powerup' | 'rehan' | 'player';
    z: number;
    data?: any;
  }

  const renderQueue: RenderableItem[] = [];

  // Add obstacles
  obstacles.forEach((obs) => {
    if (obs.z >= 0 && obs.z <= 650) {
      renderQueue.push({ type: 'obstacle', z: obs.z, data: obs });
    }
  });

  // Add coins
  coins.forEach((c) => {
    if (!c.collected && c.z >= 0 && c.z <= 650) {
      renderQueue.push({ type: 'coin', z: c.z, data: c });
    }
  });

  // Add powerups
  powerUps.forEach((pu) => {
    if (!pu.collected && pu.z >= 0 && pu.z <= 650) {
      renderQueue.push({ type: 'powerup', z: pu.z, data: pu });
    }
  });

  // Player is at z = 70
  const PLAYER_Z = 70;
  renderQueue.push({ type: 'player', z: PLAYER_Z });

  // Rehan is behind player, distance ranges e.g. 10..90 units behind player
  // When rehanDistance = 100, Rehan is far behind (z = 0 or negative/offscreen)
  // When rehanDistance = 0, Rehan is right next to player (z ~ 65)
  // When rehan is chasing: z = PLAYER_Z - (rehanDistance * 0.7 + 15)
  // If rehan's z is > 0, we render him
  const rehanZ = Math.max(10, PLAYER_Z - (rehanDistance * 0.65 + 15));
  renderQueue.push({ type: 'rehan', z: rehanZ });

  // Sort by z descending: highest Z drawn first
  renderQueue.sort((a, b) => b.z - a.z);

  // Draw items
  renderQueue.forEach((item) => {
    if (item.type === 'obstacle') {
      drawObstacle(ctx, item.data, project);
    } else if (item.type === 'coin') {
      drawCoin(ctx, item.data, project, gameTime);
    } else if (item.type === 'powerup') {
      drawPowerUp(ctx, item.data, project, gameTime);
    } else if (item.type === 'rehan') {
      drawRehan(ctx, rehanLane, rehanZ, project, gameTime, rehanDistance);
    } else if (item.type === 'player') {
      drawPlayer(ctx, playerLane, PLAYER_Z, playerY, character, project, gameTime, isJumping, isSliding, activeShield, activeMagnet, activeBoost);
    }
  });

  // Draw Particles (sparks, coin sparkles, speed lines)
  drawParticles(ctx, particles);

  // Speed lines when boosting
  if (activeBoost) {
    drawSpeedLines(ctx, width, height, gameTime);
  }

  // Draw Inspector Rehan Warning / Proximity Indicator HUD
  drawRehanWarning(ctx, width, height, rehanDistance);
}

// Background Skyline
function drawSkyline(ctx: CanvasRenderingContext2D, width: number, horizonY: number, _time: number) {
  ctx.save();
  // Distant glowing moon
  ctx.fillStyle = '#FEF08A';
  ctx.beginPath();
  ctx.arc(width * 0.8, horizonY * 0.35, 26, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = 'rgba(254, 240, 138, 0.2)';
  ctx.beginPath();
  ctx.arc(width * 0.8, horizonY * 0.35, 45, 0, Math.PI * 2);
  ctx.fill();

  // City silhouettes
  ctx.fillStyle = '#1E1B4B';
  const numBuildings = 14;
  const bWidth = width / numBuildings;
  for (let i = 0; i < numBuildings; i++) {
    const seed = (i * 137.5) % 1;
    const bHeight = 40 + seed * (horizonY * 0.55);
    const bx = i * bWidth;
    const by = horizonY - bHeight;
    ctx.fillRect(bx, by, bWidth + 1, bHeight);

    // Glowing windows
    ctx.fillStyle = (i % 2 === 0) ? 'rgba(250, 204, 21, 0.4)' : 'rgba(96, 165, 250, 0.3)';
    for (let wy = by + 6; wy < horizonY - 10; wy += 12) {
      if ((i + Math.floor(wy)) % 3 !== 0) {
        ctx.fillRect(bx + 4, wy, 4, 6);
        if (bWidth > 20) ctx.fillRect(bx + bWidth - 8, wy, 4, 6);
      }
    }
    ctx.fillStyle = '#1E1B4B';
  }

  // Billboard on the left: "REHAN CHASE"
  const billX = width * 0.12;
  const billY = horizonY - 60;
  ctx.fillStyle = '#312E81';
  ctx.fillRect(billX, billY, 70, 35);
  ctx.strokeStyle = '#F43F5E';
  ctx.lineWidth = 2;
  ctx.strokeRect(billX, billY, 70, 35);
  ctx.fillStyle = '#FFFFFF';
  ctx.font = 'bold 9px Fredoka, sans-serif';
  ctx.textAlign = 'center';
  ctx.fillText('RUN FAST!', billX + 35, billY + 22);

  ctx.restore();
}

// Draw Player (Hamza / Huzaifa / Muaviya)
function drawPlayer(
  ctx: CanvasRenderingContext2D,
  lane: number,
  z: number,
  playerY: number,
  character: CharacterDef,
  project: (lane: number, z: number, y: number) => { x: number; y: number; scale: number; p: number },
  gameTime: number,
  isJumping: boolean,
  isSliding: boolean,
  shield: boolean,
  magnet: boolean,
  boost: boolean
) {
  const { x, y, scale } = project(lane, z, playerY);

  ctx.save();
  ctx.translate(x, y);
  ctx.scale(scale, scale);

  // Shadow on ground
  const groundScale = Math.max(0.2, 1 - playerY / 180);
  ctx.fillStyle = 'rgba(0, 0, 0, 0.45)';
  ctx.beginPath();
  ctx.ellipse(0, 8, 30 * groundScale, 9 * groundScale, 0, 0, Math.PI * 2);
  ctx.fill();

  // Shield Aura
  if (shield) {
    ctx.strokeStyle = `rgba(59, 130, 246, ${0.6 + Math.sin(gameTime * 8) * 0.25})`;
    ctx.lineWidth = 5;
    ctx.beginPath();
    ctx.arc(0, -38, 48, 0, Math.PI * 2);
    ctx.stroke();

    ctx.fillStyle = 'rgba(96, 165, 250, 0.15)';
    ctx.fill();
  }

  // Magnet Aura
  if (magnet) {
    ctx.strokeStyle = `rgba(234, 179, 8, ${0.7 + Math.sin(gameTime * 10) * 0.2})`;
    ctx.lineWidth = 3;
    ctx.setLineDash([6, 6]);
    ctx.beginPath();
    ctx.arc(0, -35, 42, 0, Math.PI * 2);
    ctx.stroke();
    ctx.setLineDash([]);
  }

  // Running bobbing & leg swing
  const runFreq = boost ? 24 : 16;
  const runCycle = Math.sin(gameTime * runFreq);
  const armCycle = Math.cos(gameTime * runFreq);
  const bob = isJumping ? 0 : Math.abs(runCycle) * 4;

  if (isSliding) {
    // Sliding pose: character crouched down low on a hover-slide
    ctx.translate(0, 8);

    // Dust spray
    ctx.fillStyle = 'rgba(255, 255, 255, 0.6)';
    ctx.beginPath();
    ctx.arc(-18, -4, 5, 0, Math.PI * 2);
    ctx.arc(18, -4, 4, 0, Math.PI * 2);
    ctx.fill();

    // Body horizontal
    ctx.fillStyle = character.outfit.pantsColor;
    ctx.fillRect(-22, -18, 44, 14);

    // Torso
    ctx.fillStyle = character.outfit.shirtColor;
    ctx.fillRect(-15, -26, 30, 14);

    // Head
    ctx.fillStyle = '#FED7AA';
    ctx.beginPath();
    ctx.arc(0, -32, 11, 0, Math.PI * 2);
    ctx.fill();

    // Cap
    ctx.fillStyle = character.outfit.capColor;
    ctx.beginPath();
    ctx.arc(0, -35, 12, Math.PI, Math.PI * 2);
    ctx.fill();
    ctx.fillRect(0, -35, 14, 4); // cap visor
  } else {
    // Standard Running / Jumping
    ctx.translate(0, -bob);

    // Back leg & shoe
    const leftLegAngle = isJumping ? 0.3 : runCycle * 0.65;
    const rightLegAngle = isJumping ? -0.4 : -runCycle * 0.65;

    // Left leg
    ctx.save();
    ctx.translate(-8, -16);
    ctx.rotate(leftLegAngle);
    ctx.fillStyle = character.outfit.pantsColor;
    ctx.fillRect(-4, 0, 8, 20);
    // Left shoe
    ctx.fillStyle = character.outfit.shoesColor;
    ctx.fillRect(-5, 16, 12, 7);
    ctx.restore();

    // Right leg
    ctx.save();
    ctx.translate(8, -16);
    ctx.rotate(rightLegAngle);
    ctx.fillStyle = character.outfit.pantsColor;
    ctx.fillRect(-4, 0, 8, 20);
    // Right shoe
    ctx.fillStyle = character.outfit.shoesColor;
    ctx.fillRect(-5, 16, 12, 7);
    ctx.restore();

    // Body / Hoodie
    ctx.fillStyle = character.outfit.shirtColor;
    ctx.beginPath();
    ctx.roundRect(-16, -48, 32, 34, [8, 8, 4, 4]);
    ctx.fill();

    // Character ID stripe / graphic
    ctx.fillStyle = '#FFFFFF';
    ctx.fillRect(-12, -40, 24, 4);

    // Left Arm
    ctx.save();
    ctx.translate(-16, -42);
    ctx.rotate(armCycle * 0.6);
    ctx.fillStyle = character.outfit.shirtColor;
    ctx.fillRect(-3, 0, 6, 22);
    ctx.fillStyle = '#FED7AA';
    ctx.beginPath();
    ctx.arc(0, 22, 4, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();

    // Right Arm
    ctx.save();
    ctx.translate(16, -42);
    ctx.rotate(-armCycle * 0.6);
    ctx.fillStyle = character.outfit.shirtColor;
    ctx.fillRect(-3, 0, 6, 22);
    ctx.fillStyle = '#FED7AA';
    ctx.beginPath();
    ctx.arc(0, 22, 4, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();

    // Head
    ctx.fillStyle = '#FED7AA';
    ctx.beginPath();
    ctx.arc(0, -58, 13, 0, Math.PI * 2);
    ctx.fill();

    // Eyes looking forward
    ctx.fillStyle = '#1E293B';
    ctx.fillRect(-6, -60, 3, 4);
    ctx.fillRect(3, -60, 3, 4);

    // Cap / Hair
    ctx.fillStyle = character.outfit.capColor;
    ctx.beginPath();
    ctx.arc(0, -62, 14, Math.PI * 0.9, Math.PI * 2.1);
    ctx.fill();
    // Cap visor backwards or forward
    ctx.fillRect(3, -62, 15, 4);

    // Character name tag floating overhead
    ctx.fillStyle = 'rgba(0,0,0,0.6)';
    ctx.beginPath();
    ctx.roundRect(-25, -84, 50, 16, 8);
    ctx.fill();
    ctx.fillStyle = '#FFFFFF';
    ctx.font = 'bold 10px Fredoka, sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText(character.name, 0, -72);
  }

  ctx.restore();
}

// Draw Inspector Rehan (The Chaser with Police uniform and whistle)
function drawRehan(
  ctx: CanvasRenderingContext2D,
  lane: number,
  z: number,
  project: (lane: number, z: number, y: number) => { x: number; y: number; scale: number; p: number },
  gameTime: number,
  rehanDistance: number
) {
  const { x, y, scale } = project(lane, z, 0);

  ctx.save();
  ctx.translate(x, y);
  ctx.scale(scale * 1.15, scale * 1.15); // Rehan is bigger and intimidating

  // Rehan ground shadow
  ctx.fillStyle = 'rgba(0, 0, 0, 0.5)';
  ctx.beginPath();
  ctx.ellipse(0, 6, 32, 10, 0, 0, Math.PI * 2);
  ctx.fill();

  const runFreq = 18;
  const legCycle = Math.sin(gameTime * runFreq);
  const bob = Math.abs(legCycle) * 3;

  ctx.translate(0, -bob);

  // Legs (Dark Navy Police Trousers)
  ctx.fillStyle = '#0F172A';
  // Left leg
  ctx.save();
  ctx.translate(-9, -18);
  ctx.rotate(legCycle * 0.7);
  ctx.fillRect(-5, 0, 10, 22);
  ctx.fillStyle = '#000000';
  ctx.fillRect(-6, 18, 14, 8); // Police boots
  ctx.restore();

  // Right leg
  ctx.save();
  ctx.translate(9, -18);
  ctx.rotate(-legCycle * 0.7);
  ctx.fillStyle = '#0F172A';
  ctx.fillRect(-5, 0, 10, 22);
  ctx.fillStyle = '#000000';
  ctx.fillRect(-6, 18, 14, 8);
  ctx.restore();

  // Police Uniform Torso (Khaki/Tan or Navy Police with badge)
  ctx.fillStyle = '#1E3A8A'; // Deep Inspector Navy
  ctx.beginPath();
  ctx.roundRect(-20, -56, 40, 40, [10, 10, 4, 4]);
  ctx.fill();

  // Police Badge
  ctx.fillStyle = '#F59E0B';
  ctx.beginPath();
  ctx.moveTo(8, -48);
  ctx.lineTo(13, -42);
  ctx.lineTo(8, -36);
  ctx.lineTo(3, -42);
  ctx.closePath();
  ctx.fill();

  // White tie/collar
  ctx.fillStyle = '#FFFFFF';
  ctx.beginPath();
  ctx.moveTo(-4, -56);
  ctx.lineTo(4, -56);
  ctx.lineTo(0, -44);
  ctx.closePath();
  ctx.fill();

  // Rehan's Hand reaching out trying to catch you!
  ctx.save();
  ctx.translate(18, -44);
  ctx.rotate(-0.8 + Math.sin(gameTime * 12) * 0.3); // aggressive grasping arm
  ctx.fillStyle = '#1E3A8A';
  ctx.fillRect(-4, 0, 8, 26);
  ctx.fillStyle = '#D97706'; // Hand
  ctx.beginPath();
  ctx.arc(0, 26, 6, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();

  // Left arm holding flashlight or baton
  ctx.save();
  ctx.translate(-18, -44);
  ctx.rotate(0.6 + Math.cos(gameTime * 12) * 0.3);
  ctx.fillStyle = '#1E3A8A';
  ctx.fillRect(-4, 0, 8, 24);
  // Baton / stick
  ctx.fillStyle = '#475569';
  ctx.fillRect(-2, 20, 6, 18);
  ctx.restore();

  // Head
  ctx.fillStyle = '#FBBF24'; // Flesh tone
  ctx.beginPath();
  ctx.arc(0, -68, 14, 0, Math.PI * 2);
  ctx.fill();

  // Mustache & Angry Eyebrows (Signature Inspector look!)
  ctx.fillStyle = '#1E293B';
  // Angry eyebrows
  ctx.fillRect(-9, -74, 7, 3);
  ctx.fillRect(2, -74, 7, 3);
  // Angry eyes
  ctx.fillRect(-7, -70, 3, 3);
  ctx.fillRect(4, -70, 3, 3);
  // Signature Mustache
  ctx.fillRect(-8, -63, 16, 4);

  // Inspector Cap (Peaked Police Cap)
  ctx.fillStyle = '#1E3A8A';
  ctx.beginPath();
  ctx.roundRect(-16, -82, 32, 12, [5, 5, 0, 0]);
  ctx.fill();
  // Cap Visor
  ctx.fillStyle = '#0F172A';
  ctx.fillRect(-18, -72, 36, 4);
  // Gold badge on cap
  ctx.fillStyle = '#FBBF24';
  ctx.beginPath();
  ctx.arc(0, -78, 4, 0, Math.PI * 2);
  ctx.fill();

  // Name tag: "INSPECTOR REHAN"
  ctx.fillStyle = '#DC2626';
  ctx.beginPath();
  ctx.roundRect(-42, -100, 84, 16, 8);
  ctx.fill();
  ctx.fillStyle = '#FFFFFF';
  ctx.font = 'bold 9px Fredoka, sans-serif';
  ctx.textAlign = 'center';
  ctx.fillText('🚨 REHAN CHASE', 0, -88);

  // Speech bubble if Rehan is super close (< 35)
  if (rehanDistance < 35) {
    const shouts = ['STOP HAMZA!', 'HUZAIFA WAIT!', 'MUAVIYA STOP!', 'GOTCHA!'];
    const shout = shouts[Math.floor((gameTime * 0.8) % shouts.length)];
    ctx.fillStyle = '#FFFFFF';
    ctx.beginPath();
    ctx.roundRect(24, -125, 80, 22, 6);
    ctx.fill();
    ctx.fillStyle = '#DC2626';
    ctx.font = 'bold 9px Bungee, sans-serif';
    ctx.fillText(shout, 64, -110);
  }

  ctx.restore();
}

// Draw Obstacle (Subway Train, Low Barrier, High Barricade, Police Cruiser)
function drawObstacle(
  ctx: CanvasRenderingContext2D,
  obs: Obstacle,
  project: (lane: number, z: number, y: number) => { x: number; y: number; scale: number; p: number }
) {
  const { x, y, scale } = project(obs.lane, obs.z, 0);

  ctx.save();
  ctx.translate(x, y);
  ctx.scale(scale, scale);

  switch (obs.type) {
    case 'barrier_low': {
      // Low wooden / striped construction hurdle: can jump over
      ctx.fillStyle = 'rgba(0, 0, 0, 0.4)';
      ctx.fillRect(-35, -4, 70, 8);

      // Legs
      ctx.fillStyle = '#78350F';
      ctx.fillRect(-32, -30, 8, 30);
      ctx.fillRect(24, -30, 8, 30);

      // Warning beam with yellow/black hazard stripes
      ctx.fillStyle = '#EAB308';
      ctx.fillRect(-36, -34, 72, 16);
      ctx.fillStyle = '#000000';
      for (let s = -32; s < 32; s += 14) {
        ctx.beginPath();
        ctx.moveTo(s, -18);
        ctx.lineTo(s + 6, -34);
        ctx.lineTo(s + 11, -34);
        ctx.lineTo(s + 5, -18);
        ctx.closePath();
        ctx.fill();
      }

      // Small "JUMP" hint
      ctx.fillStyle = 'rgba(255, 255, 255, 0.9)';
      ctx.font = 'bold 8px Fredoka, sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('▲ JUMP', 0, -38);
      break;
    }

    case 'barrier_high': {
      // High overhead barrier: must slide underneath or dodge
      ctx.fillStyle = 'rgba(0, 0, 0, 0.4)';
      ctx.fillRect(-36, -4, 72, 8);

      // Tall metal scaffold poles
      ctx.fillStyle = '#475569';
      ctx.fillRect(-35, -90, 8, 90);
      ctx.fillRect(27, -90, 8, 90);

      // Top heavy bar (clear underneath for sliding)
      ctx.fillStyle = '#DC2626';
      ctx.fillRect(-38, -90, 76, 40);

      // Hazard stripes on high block
      ctx.fillStyle = '#FFFFFF';
      for (let s = -34; s < 34; s += 16) {
        ctx.beginPath();
        ctx.moveTo(s, -50);
        ctx.lineTo(s + 8, -90);
        ctx.lineTo(s + 14, -90);
        ctx.lineTo(s + 6, -50);
        ctx.closePath();
        ctx.fill();
      }

      // "SLIDE" hint
      ctx.fillStyle = '#FACC15';
      ctx.font = 'bold 9px Bungee, sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('▼ SLIDE', 0, -22);
      break;
    }

    case 'police_car': {
      // Rehan's squad car parked on the track
      ctx.fillStyle = 'rgba(0, 0, 0, 0.45)';
      ctx.fillRect(-45, -6, 90, 12);

      // Wheels
      ctx.fillStyle = '#18181B';
      ctx.fillRect(-42, -14, 16, 16);
      ctx.fillRect(26, -14, 16, 16);

      // Car body
      ctx.fillStyle = '#FFFFFF';
      ctx.beginPath();
      ctx.roundRect(-42, -38, 84, 28, [6, 6, 2, 2]);
      ctx.fill();

      // Police blue doors
      ctx.fillStyle = '#1E3A8A';
      ctx.fillRect(-30, -38, 60, 20);

      // Text
      ctx.fillStyle = '#FFFFFF';
      ctx.font = 'bold 9px Fredoka, sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('POLICE', 0, -24);

      // Cabin / windshield
      ctx.fillStyle = '#0284C7';
      ctx.beginPath();
      ctx.roundRect(-24, -58, 48, 22, [6, 6, 0, 0]);
      ctx.fill();

      // Flashing Siren Bar
      const blink = Math.sin(Date.now() * 0.015) > 0;
      ctx.fillStyle = blink ? '#EF4444' : '#3B82F6';
      ctx.fillRect(-12, -66, 12, 8);
      ctx.fillStyle = blink ? '#3B82F6' : '#EF4444';
      ctx.fillRect(0, -66, 12, 8);
      break;
    }

    case 'train': {
      // Giant Karachi Metro Train coming or stationary
      ctx.fillStyle = 'rgba(0, 0, 0, 0.5)';
      ctx.fillRect(-48, -4, 96, 12);

      // Train body (Front face)
      ctx.fillStyle = '#E11D48'; // Bright Rose/Red Train
      ctx.beginPath();
      ctx.roundRect(-46, -110, 92, 110, [12, 12, 4, 4]);
      ctx.fill();

      // Front Windshield
      ctx.fillStyle = '#0F172A';
      ctx.beginPath();
      ctx.roundRect(-36, -98, 72, 34, [6, 6, 2, 2]);
      ctx.fill();

      // Reflection
      ctx.fillStyle = 'rgba(255, 255, 255, 0.2)';
      ctx.fillRect(-30, -94, 20, 26);

      // Train Headlights
      ctx.fillStyle = '#FEF08A';
      ctx.beginPath();
      ctx.arc(-24, -48, 9, 0, Math.PI * 2);
      ctx.arc(24, -48, 9, 0, Math.PI * 2);
      ctx.fill();

      // Subway Grill
      ctx.fillStyle = '#475569';
      ctx.fillRect(-32, -30, 64, 18);
      ctx.fillStyle = '#1E293B';
      for (let g = -26; g <= 26; g += 10) {
        ctx.fillRect(g, -28, 4, 14);
      }

      // Train route number
      ctx.fillStyle = '#FACC15';
      ctx.font = 'bold 9px Bungee, sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('EXPRESS 7', 0, -102);
      break;
    }

    default: {
      // Traffic Cone
      ctx.fillStyle = '#EA580C';
      ctx.beginPath();
      ctx.moveTo(0, -32);
      ctx.lineTo(16, 0);
      ctx.lineTo(-16, 0);
      ctx.closePath();
      ctx.fill();

      // White reflective stripe
      ctx.fillStyle = '#FFFFFF';
      ctx.beginPath();
      ctx.moveTo(-7, -14);
      ctx.lineTo(7, -14);
      ctx.lineTo(11, -7);
      ctx.lineTo(-11, -7);
      ctx.closePath();
      ctx.fill();
    }
  }

  ctx.restore();
}

// Draw Spinning 3D Gold Coin
function drawCoin(
  ctx: CanvasRenderingContext2D,
  coin: Coin,
  project: (lane: number, z: number, y: number) => { x: number; y: number; scale: number; p: number },
  gameTime: number
) {
  const { x, y, scale } = project(coin.lane, coin.z, coin.y);

  ctx.save();
  ctx.translate(x, y);
  ctx.scale(scale, scale);

  // Spin rotation squishing X
  const spin = Math.sin(gameTime * 6 + coin.id);
  const coinW = Math.max(3, Math.abs(spin) * 16);

  // Outer gold rim
  ctx.fillStyle = '#F59E0B';
  ctx.beginPath();
  ctx.ellipse(0, 0, coinW, 16, 0, 0, Math.PI * 2);
  ctx.fill();

  // Inner bright coin face
  ctx.fillStyle = '#FBBF24';
  ctx.beginPath();
  ctx.ellipse(0, 0, Math.max(1, coinW - 3), 13, 0, 0, Math.PI * 2);
  ctx.fill();

  // Coin star or shine
  ctx.fillStyle = '#FEF08A';
  ctx.beginPath();
  ctx.ellipse(0, 0, Math.max(1, coinW * 0.4), 6, 0, 0, Math.PI * 2);
  ctx.fill();

  ctx.restore();
}

// Draw Power-Up Box/Capsule (Magnet, Shield, Boost, 2x)
function drawPowerUp(
  ctx: CanvasRenderingContext2D,
  pu: PowerUpItem,
  project: (lane: number, z: number, y: number) => { x: number; y: number; scale: number; p: number },
  gameTime: number
) {
  const floatBob = Math.sin(gameTime * 4 + pu.id) * 8;
  const { x, y, scale } = project(pu.lane, pu.z, 28 + floatBob);

  ctx.save();
  ctx.translate(x, y);
  ctx.scale(scale, scale);

  // Floating shadow on ground
  const groundPos = project(pu.lane, pu.z, 0);
  ctx.save();
  ctx.setTransform(1, 0, 0, 1, 0, 0);
  ctx.fillStyle = 'rgba(0, 0, 0, 0.3)';
  ctx.beginPath();
  ctx.ellipse(groundPos.x, groundPos.y, 16 * scale, 6 * scale, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();

  // Glowing orb container
  let bgCol = '#3B82F6';
  let icon = '🛡️';
  if (pu.type === 'magnet') {
    bgCol = '#F59E0B';
    icon = '🧲';
  } else if (pu.type === 'boost') {
    bgCol = '#10B981';
    icon = '🚀';
  } else if (pu.type === '2x') {
    bgCol = '#EC4899';
    icon = '2X';
  }

  // Pulsing glow
  ctx.fillStyle = bgCol;
  ctx.beginPath();
  ctx.arc(0, 0, 20, 0, Math.PI * 2);
  ctx.fill();

  ctx.strokeStyle = '#FFFFFF';
  ctx.lineWidth = 3;
  ctx.beginPath();
  ctx.arc(0, 0, 20, 0, Math.PI * 2);
  ctx.stroke();

  // Text / Emoji
  ctx.fillStyle = '#FFFFFF';
  ctx.font = pu.type === '2x' ? 'bold 15px Bungee, sans-serif' : '17px Fredoka, sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(icon, 0, 2);

  ctx.restore();
}

// Speed Lines during Boost
function drawSpeedLines(ctx: CanvasRenderingContext2D, width: number, height: number, time: number) {
  ctx.save();
  ctx.strokeStyle = 'rgba(255, 255, 255, 0.45)';
  ctx.lineWidth = 2.5;

  const vpX = width / 2;
  const vpY = height * 0.38;

  for (let i = 0; i < 18; i++) {
    const angle = (i / 18) * Math.PI * 2;
    const offset = ((time * 1200 + i * 150) % 600);
    const startR = 80 + offset;
    const endR = startR + 60;

    const x1 = vpX + Math.cos(angle) * startR;
    const y1 = vpY + Math.sin(angle) * startR;
    const x2 = vpX + Math.cos(angle) * endR;
    const y2 = vpY + Math.sin(angle) * endR;

    ctx.beginPath();
    ctx.moveTo(x1, y1);
    ctx.lineTo(x2, y2);
    ctx.stroke();
  }
  ctx.restore();
}

// Particle rendering
function drawParticles(ctx: CanvasRenderingContext2D, particles: Particle[]) {
  ctx.save();
  for (let i = particles.length - 1; i >= 0; i--) {
    const p = particles[i];
    ctx.globalAlpha = Math.max(0, p.alpha);
    ctx.fillStyle = p.color;
    ctx.beginPath();
    ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.restore();
}

// Danger Proximity HUD Indicator for Rehan
function drawRehanWarning(ctx: CanvasRenderingContext2D, width: number, height: number, rehanDistance: number) {
  // If Rehan is closer than 40%, show glowing red edge vignette
  if (rehanDistance < 45) {
    const danger = 1 - rehanDistance / 45; // 0 to 1
    const pulse = Math.sin(Date.now() * 0.012) * 0.2 + 0.8;
    const alpha = danger * 0.35 * pulse;

    ctx.save();
    const grad = ctx.createRadialGradient(
      width / 2, height / 2, width * 0.3,
      width / 2, height / 2, width * 0.7
    );
    grad.addColorStop(0, 'rgba(220, 38, 38, 0)');
    grad.addColorStop(1, `rgba(220, 38, 38, ${alpha})`);
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, width, height);
    ctx.restore();
  }
}
