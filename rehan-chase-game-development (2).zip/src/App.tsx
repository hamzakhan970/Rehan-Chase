import { useState, useEffect } from 'react';
import { GameCanvas } from './components/GameCanvas';
import { CharacterModal } from './components/CharacterModal';
import { LoadingScreen } from './components/LoadingScreen';
import { CHARACTERS, CharacterDef } from './types/game';

export default function App() {
  const [isLoading, setIsLoading] = useState<boolean>(true);

  // Saved persistence for highscore and coins
  const [highScore, setHighScore] = useState<number>(() => {
    const saved = localStorage.getItem('rehan_chase_highscore');
    return saved ? parseInt(saved, 10) : 0;
  });

  const [totalCoins, setTotalCoins] = useState<number>(() => {
    const saved = localStorage.getItem('rehan_chase_coins');
    return saved ? parseInt(saved, 10) : 0;
  });

  const [selectedCharacter, setSelectedCharacter] = useState<CharacterDef>(() => {
    const savedId = localStorage.getItem('rehan_chase_char');
    const found = CHARACTERS.find((c) => c.id === savedId);
    return found || CHARACTERS[0]; // Hamza by default
  });

  const [isCharModalOpen, setIsCharModalOpen] = useState<boolean>(false);

  const handleUpdateHighScore = (score: number) => {
    setHighScore(score);
    localStorage.setItem('rehan_chase_highscore', score.toString());
  };

  const handleAddCoins = (earned: number) => {
    setTotalCoins((prev) => {
      const updated = prev + earned;
      localStorage.setItem('rehan_chase_coins', updated.toString());
      return updated;
    });
  };

  const handleSelectCharacter = (char: CharacterDef) => {
    setSelectedCharacter(char);
    localStorage.setItem('rehan_chase_char', char.id);
  };

  // Prevent default scroll behaviors on mobile touch
  useEffect(() => {
    const preventTouchScroll = (e: TouchEvent) => {
      if (e.target instanceof HTMLCanvasElement) {
        e.preventDefault();
      }
    };
    document.addEventListener('touchmove', preventTouchScroll, { passive: false });
    return () => document.removeEventListener('touchmove', preventTouchScroll);
  }, []);

  if (isLoading) {
    return <LoadingScreen onComplete={() => setIsLoading(false)} />;
  }

  return (
    <div className="w-screen h-screen overflow-hidden bg-slate-950 flex flex-col items-center justify-center">
      {/* Playable Game Viewport */}
      <main className="w-full h-full max-w-lg mx-auto relative shadow-2xl overflow-hidden flex flex-col">
        <GameCanvas
          character={selectedCharacter}
          onOpenSelectCharacter={() => setIsCharModalOpen(true)}
          highScore={highScore}
          totalCoins={totalCoins}
          onUpdateHighScore={handleUpdateHighScore}
          onAddCoins={handleAddCoins}
        />
      </main>

      {/* Character Selection Modal */}
      <CharacterModal
        isOpen={isCharModalOpen}
        onClose={() => setIsCharModalOpen(false)}
        selectedCharacter={selectedCharacter}
        onSelectCharacter={handleSelectCharacter}
        highScore={highScore}
        totalCoins={totalCoins}
      />
    </div>
  );
}
