import React from 'react';
import { CHARACTERS, CharacterDef } from '../types/game';
import { X, Lock, Check, Zap, ArrowRight, Shield, Magnet } from 'lucide-react';

interface CharacterModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedCharacter: CharacterDef;
  onSelectCharacter: (char: CharacterDef) => void;
  highScore: number;
  totalCoins: number;
}

export const CharacterModal: React.FC<CharacterModalProps> = ({
  isOpen,
  onClose,
  selectedCharacter,
  onSelectCharacter,
  highScore,
  totalCoins,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fadeIn font-['Fredoka',sans-serif]">
      <div className="relative w-full max-w-lg bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-2xl flex flex-col max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <div>
            <h2 className="text-2xl font-black text-white font-['Bungee',sans-serif]">
              CHOOSE RUNNER
            </h2>
            <p className="text-slate-400 text-xs">
              Pick your escape hero: Hamza, Huzaifa, or Muaviya!
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-slate-800 text-slate-400 hover:text-white transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Balance Bar */}
        <div className="flex items-center justify-between bg-slate-950/60 px-4 py-2 rounded-2xl my-4 border border-slate-800">
          <div className="flex items-center gap-1.5 text-xs text-slate-400 font-semibold">
            <span>High Score:</span>
            <span className="text-white font-black">{highScore.toLocaleString()}</span>
          </div>
          <div className="flex items-center gap-1.5 text-xs text-amber-300 font-bold">
            <span>🪙 {totalCoins}</span>
          </div>
        </div>

        {/* Character Cards List */}
        <div className="flex-1 overflow-y-auto space-y-3.5 pr-1 py-1">
          {CHARACTERS.map((char) => {
            const isUnlocked = highScore >= char.unlockScore;
            const isSelected = selectedCharacter.id === char.id;

            return (
              <div
                key={char.id}
                onClick={() => {
                  if (isUnlocked) {
                    onSelectCharacter(char);
                    onClose();
                  }
                }}
                className={`p-4 rounded-2xl border transition-all cursor-pointer relative overflow-hidden flex flex-col gap-2 ${
                  isSelected
                    ? 'border-blue-500 bg-blue-950/30 shadow-lg shadow-blue-950/50'
                    : isUnlocked
                    ? 'border-slate-800 bg-slate-800/40 hover:bg-slate-800/80 hover:border-slate-700'
                    : 'border-slate-800/50 bg-slate-900/40 opacity-70 cursor-not-allowed'
                }`}
              >
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3.5">
                    {/* Emoji Avatar */}
                    <div
                      className="w-14 h-14 rounded-2xl flex items-center justify-center text-3xl shadow-inner border border-white/20 shrink-0"
                      style={{ backgroundColor: char.color }}
                    >
                      {char.avatarEmoji}
                    </div>

                    <div>
                      <div className="flex items-center gap-2">
                        <h3 className="text-lg font-black text-white">{char.name}</h3>
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-800 text-slate-300">
                          {char.role}
                        </span>
                      </div>
                      <p className="text-xs font-semibold text-slate-400">{char.nickname}</p>
                      <p className="text-[11px] text-slate-400 italic mt-0.5">{char.tagline}</p>
                    </div>
                  </div>

                  {/* Status Indicator */}
                  <div>
                    {isSelected ? (
                      <span className="flex items-center gap-1 bg-blue-600 text-white text-xs font-black px-2.5 py-1 rounded-full shadow">
                        <Check className="w-3.5 h-3.5" /> ACTIVE
                      </span>
                    ) : isUnlocked ? (
                      <button className="flex items-center gap-1 bg-slate-800 hover:bg-blue-600 text-white text-xs font-bold px-3 py-1 rounded-full transition">
                        SELECT <ArrowRight className="w-3 h-3" />
                      </button>
                    ) : (
                      <div className="flex items-center gap-1 text-slate-400 text-xs font-bold bg-slate-800/80 px-2 py-1 rounded-full">
                        <Lock className="w-3 h-3 text-red-400" />
                        <span>Unlock at {char.unlockScore.toLocaleString()} pts</span>
                      </div>
                    )}
                  </div>
                </div>

                {/* Stat Perks */}
                <div className="grid grid-cols-3 gap-2 mt-1 pt-2 border-t border-slate-800/60 text-[11px]">
                  <div className="flex items-center gap-1 text-blue-400 font-semibold">
                    <Zap className="w-3.5 h-3.5" />
                    <span>Speed: {Math.round(char.speedBonus * 100)}%</span>
                  </div>
                  <div className="flex items-center gap-1 text-emerald-400 font-semibold">
                    <Shield className="w-3.5 h-3.5" />
                    <span>Jump: {Math.round(char.jumpBonus * 100)}%</span>
                  </div>
                  <div className="flex items-center gap-1 text-amber-400 font-semibold">
                    <Magnet className="w-3.5 h-3.5" />
                    <span>Magnet: {Math.round(char.magnetBonus * 100)}%</span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Rehan Info Box */}
        <div className="mt-4 p-3 bg-red-950/30 border border-red-900/40 rounded-2xl flex items-center gap-3">
          <div className="text-2xl">👮</div>
          <div className="text-left text-xs">
            <span className="text-red-400 font-bold block">The Chaser: Inspector Rehan</span>
            <span className="text-slate-400">
              He pursues with a whistle, police cruisers, and subway hurdles. Never stumble!
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
