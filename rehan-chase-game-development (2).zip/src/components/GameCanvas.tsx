import React, { useEffect, useRef, useState, useCallback } from 'react';
import { CharacterDef, Obstacle, Coin, PowerUpItem, Particle } from '../types/game';
import { drawRunnerScene } from '../utils/renderer';
import { sounds } from '../utils/audio';
import confetti from 'canvas-confetti';
import {
  Volume2,
  VolumeX,
  Play,
  RotateCcw,
  Sparkles,
  Zap,
  ArrowLeft,
  ArrowRight,
  ArrowUp,
  ArrowDown,
  Trophy,
  Users
} from 'lucide-react';

interface GameCanvasProps {
  character: CharacterDef;
  onOpenSelectCharacter: () => void;
  highScore: number;
  totalCoins: number;
  onUpdateHighScore: (score: number) => void;
  onAddCoins: (coins: number) => void;
}

export const GameCanvas: React.FC<GameCanvasProps> = ({
  character,
  onOpenSelectCharacter,
  highScore,
  totalCoins: _totalCoins,
  onUpdateHighScore,
  onAddCoins
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Game state
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [isGameOver, setIsGameOver] = useState<boolean>(false);
  const [isPaused, setIsPaused] = useState<boolean>(false);
  const [soundMuted, setSoundMuted] = useState<boolean>(false);

  // Stats displayed on UI
  const [score, setScore] = useState<number>(0);
  const [runCoins, setRunCoins] = useState<number>(0);
  const [_multiplier, setMultiplier] = useState<number>(1);
  const [activePowerUpName, setActivePowerUpName] = useState<string | null>(null);
  const [powerUpTimeLeft, setPowerUpTimeLeft] = useState<number>(0);

  // Rehan Proximity Alert State
  const [rehanProximity, setRehanProximity] = useState<number>(70); // 0 (caught) to 100 (safe)
  const [rehanAlertMessage, setRehanAlertMessage] = useState<string>('Rehan is on your tail!');

  // Mutable Game Engine Variables (Refs for smooth 60fps loop)
  const engineRef = useRef({
    currentLane: 0, // -1, 0, 1
    targetLane: 0,
    playerLaneSmooth: 0,
    playerY: 0,
    playerVY: 0,
    isJumping: false,
    isSliding: false,
    slideTimer: 0,
    gameSpeed: 380, // units per second
    baseSpeed: 380,
    distanceTraveled: 0,
    coinsEarned: 0,
    scoreVal: 0,
    rehanDistance: 70, // 0 to 100
    rehanLane: 0,
    rehanCatchTimer: 0,
    lastTime: 0,
    gameTime: 0,
    nextObstacleZ: 500,
    nextCoinZ: 300,
    nextPowerUpZ: 1200,
    activeShield: false,
    shieldTimer: 0,
    activeMagnet: false,
    magnetTimer: 0,
    activeBoost: false,
    boostTimer: 0,
    active2x: false,
    doubleTimer: 0,
    obstacles: [] as Obstacle[],
    coins: [] as Coin[],
    powerUps: [] as PowerUpItem[],
    particles: [] as Particle[],
  });

  // Touch swipe support
  const touchStartRef = useRef<{ x: number; y: number; time: number } | null>(null);

  // Reset or initialize run
  const resetGame = useCallback(() => {
    const eng = engineRef.current;
    eng.currentLane = 0;
    eng.targetLane = 0;
    eng.playerLaneSmooth = 0;
    eng.playerY = 0;
    eng.playerVY = 0;
    eng.isJumping = false;
    eng.isSliding = false;
    eng.slideTimer = 0;
    eng.baseSpeed = 400 * character.speedBonus;
    eng.gameSpeed = eng.baseSpeed;
    eng.distanceTraveled = 0;
    eng.coinsEarned = 0;
    eng.scoreVal = 0;
    eng.rehanDistance = 75; // starts moderately safe
    eng.rehanLane = 0;
    eng.rehanCatchTimer = 0;
    eng.activeShield = false;
    eng.shieldTimer = 0;
    eng.activeMagnet = false;
    eng.magnetTimer = 0;
    eng.activeBoost = false;
    eng.boostTimer = 0;
    eng.active2x = false;
    eng.doubleTimer = 0;
    eng.obstacles = [];
    eng.coins = [];
    eng.powerUps = [];
    eng.particles = [];
    eng.nextObstacleZ = 450;
    eng.nextCoinZ = 250;
    eng.nextPowerUpZ = 800;

    // Seed initial obstacles and coins
    for (let i = 0; i < 4; i++) {
      spawnObstacleBatch(400 + i * 220);
    }

    setScore(0);
    setRunCoins(0);
    setMultiplier(1);
    setActivePowerUpName(null);
    setPowerUpTimeLeft(0);
    setRehanProximity(75);
    setIsGameOver(false);
    setIsPaused(false);
  }, [character]);

  const startGame = () => {
    resetGame();
    setIsPlaying(true);
    sounds.playWhistle();
  };

  // Helper: Spawning obstacles
  const spawnObstacleBatch = (zPos: number) => {
    const eng = engineRef.current;
    const laneChoices = [-1, 0, 1];
    const lane = laneChoices[Math.floor(Math.random() * laneChoices.length)];

    const types: Obstacle['type'][] = [
      'barrier_low',
      'barrier_low',
      'barrier_high',
      'police_car',
      'train',
      'construction_barrier'
    ];
    const type = types[Math.floor(Math.random() * types.length)];

    eng.obstacles.push({
      id: Date.now() + Math.random(),
      lane,
      z: zPos,
      type,
      width: 40,
      height: type === 'train' ? 110 : (type === 'barrier_high' ? 80 : 35)
    });

    // 40% chance of a second lane obstacle if not train, leaving at least 1 open lane
    if (type !== 'train' && Math.random() < 0.4) {
      const remainingLanes = laneChoices.filter(l => l !== lane);
      const lane2 = remainingLanes[Math.floor(Math.random() * remainingLanes.length)];
      eng.obstacles.push({
        id: Date.now() + Math.random() + 1,
        lane: lane2,
        z: zPos + 15,
        type: 'barrier_low',
        width: 40,
        height: 35
      });
    }

    // Spawn coin arc in the free lane
    const openLane = laneChoices.find(l => l !== lane) ?? 0;
    for (let c = 0; c < 5; c++) {
      eng.coins.push({
        id: Date.now() + Math.random() + c,
        lane: openLane,
        z: zPos - 120 + c * 35,
        y: (type === 'barrier_low' && c >= 1 && c <= 3) ? 45 : 0
      });
    }

    // Occasional PowerUp
    if (Math.random() < 0.22) {
      const puTypes: PowerUpItem['type'][] = ['magnet', 'shield', 'boost', '2x'];
      const puType = puTypes[Math.floor(Math.random() * puTypes.length)];
      eng.powerUps.push({
        id: Date.now() + Math.random(),
        lane: openLane,
        z: zPos + 90,
        type: puType
      });
    }
  };

  // Player controls
  const moveLeft = useCallback(() => {
    const eng = engineRef.current;
    if (eng.targetLane > -1) {
      eng.targetLane -= 1;
      sounds.playSwitch();
    }
  }, []);

  const moveRight = useCallback(() => {
    const eng = engineRef.current;
    if (eng.targetLane < 1) {
      eng.targetLane += 1;
      sounds.playSwitch();
    }
  }, []);

  const jump = useCallback(() => {
    const eng = engineRef.current;
    if (!eng.isJumping) {
      eng.isJumping = true;
      eng.isSliding = false;
      eng.playerVY = 580 * character.jumpBonus;
      sounds.playJump();
    }
  }, [character]);

  const slide = useCallback(() => {
    const eng = engineRef.current;
    if (!eng.isSliding) {
      eng.isSliding = true;
      eng.slideTimer = 0.65; // slide lasts 0.65s
      sounds.playSwitch();
      // Fast downward plunge if already jumping
      if (eng.isJumping) {
        eng.playerVY = -500;
      }
    }
  }, []);

  // Keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!isPlaying || isGameOver || isPaused) {
        if (e.code === 'Space' && !isPlaying) {
          startGame();
        }
        return;
      }

      switch (e.code) {
        case 'ArrowLeft':
        case 'KeyA':
          moveLeft();
          break;
        case 'ArrowRight':
        case 'KeyD':
          moveRight();
          break;
        case 'ArrowUp':
        case 'KeyW':
        case 'Space':
          jump();
          break;
        case 'ArrowDown':
        case 'KeyS':
          slide();
          break;
        case 'KeyP':
          setIsPaused(prev => !prev);
          break;
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isPlaying, isGameOver, isPaused, moveLeft, moveRight, jump, slide]);

  // Touch Gesture Handling
  const handleTouchStart = (e: React.TouchEvent) => {
    if (e.touches.length > 0) {
      touchStartRef.current = {
        x: e.touches[0].clientX,
        y: e.touches[0].clientY,
        time: Date.now()
      };
    }
  };

  const handleTouchEnd = (e: React.TouchEvent) => {
    if (!touchStartRef.current) return;
    const start = touchStartRef.current;
    const endX = e.changedTouches[0].clientX;
    const endY = e.changedTouches[0].clientY;
    const dx = endX - start.x;
    const dy = endY - start.y;
    const dt = Date.now() - start.time;

    const absDx = Math.abs(dx);
    const absDy = Math.abs(dy);

    // Minimum swipe threshold
    if (Math.max(absDx, absDy) > 25 && dt < 450) {
      if (absDx > absDy) {
        // Horizontal Swipe
        if (dx > 0) {
          moveRight();
        } else {
          moveLeft();
        }
      } else {
        // Vertical Swipe
        if (dy < 0) {
          jump();
        } else {
          slide();
        }
      }
    } else if (Math.max(absDx, absDy) <= 15) {
      // Tap counts as jump
      if (!isPlaying) {
        startGame();
      } else {
        jump();
      }
    }
    touchStartRef.current = null;
  };

  // Particle burst helper
  const addParticleBurst = (x: number, y: number, color: string, count = 12) => {
    const eng = engineRef.current;
    for (let i = 0; i < count; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = 40 + Math.random() * 100;
      eng.particles.push({
        x,
        y,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed,
        color,
        size: 3 + Math.random() * 4,
        alpha: 1,
        life: 0.6
      });
    }
  };

  // Main Game Loop (requestAnimationFrame)
  useEffect(() => {
    let animId: number;

    const gameLoop = (timestamp: number) => {
      const eng = engineRef.current;
      if (!eng.lastTime) eng.lastTime = timestamp;
      const dt = Math.min((timestamp - eng.lastTime) / 1000, 0.1); // prevent huge dt
      eng.lastTime = timestamp;

      const canvas = canvasRef.current;
      if (!canvas) {
        animId = requestAnimationFrame(gameLoop);
        return;
      }
      const ctx = canvas.getContext('2d');
      if (!ctx) {
        animId = requestAnimationFrame(gameLoop);
        return;
      }

      // Sync canvas pixel resolution to container
      const rect = canvas.getBoundingClientRect();
      if (canvas.width !== rect.width || canvas.height !== rect.height) {
        canvas.width = rect.width;
        canvas.height = rect.height;
      }

      if (isPlaying && !isGameOver && !isPaused) {
        eng.gameTime += dt;

        // 1. Update Speed & Difficulty progression
        const speedBoost = eng.activeBoost ? 1.7 : 1.0;
        eng.baseSpeed = Math.min(850, 400 * character.speedBonus + eng.gameTime * 4.5);
        eng.gameSpeed = eng.baseSpeed * speedBoost;

        // 2. Smooth lane transition
        const laneLerpSpeed = 14;
        eng.playerLaneSmooth += (eng.targetLane - eng.playerLaneSmooth) * Math.min(1, dt * laneLerpSpeed);

        // Rehan chases the player lane with slight delay
        eng.rehanLane += (eng.targetLane - eng.rehanLane) * Math.min(1, dt * 5);

        // 3. Jump Physics
        if (eng.isJumping) {
          eng.playerY += eng.playerVY * dt;
          eng.playerVY -= 1500 * dt; // Gravity
          if (eng.playerY <= 0) {
            eng.playerY = 0;
            eng.playerVY = 0;
            eng.isJumping = false;
          }
        }

        // 4. Slide duration
        if (eng.isSliding) {
          eng.slideTimer -= dt;
          if (eng.slideTimer <= 0) {
            eng.isSliding = false;
          }
        }

        // 5. Power-up Timers
        if (eng.activeShield) {
          eng.shieldTimer -= dt;
          if (eng.shieldTimer <= 0) eng.activeShield = false;
        }
        if (eng.activeMagnet) {
          eng.magnetTimer -= dt;
          if (eng.magnetTimer <= 0) eng.activeMagnet = false;
        }
        if (eng.activeBoost) {
          eng.boostTimer -= dt;
          if (eng.boostTimer <= 0) eng.activeBoost = false;
        }
        if (eng.active2x) {
          eng.doubleTimer -= dt;
          if (eng.doubleTimer <= 0) eng.active2x = false;
        }

        // Update active powerup timer UI
        let activeTimer = 0;
        let activeName: string | null = null;
        if (eng.activeBoost) {
          activeName = 'Super Boost 🚀';
          activeTimer = eng.boostTimer;
        } else if (eng.activeShield) {
          activeName = 'Energy Shield 🛡️';
          activeTimer = eng.shieldTimer;
        } else if (eng.activeMagnet) {
          activeName = 'Coin Magnet 🧲';
          activeTimer = eng.magnetTimer;
        } else if (eng.active2x) {
          activeName = '2X Score Multiplier ⭐';
          activeTimer = eng.doubleTimer;
        }
        setActivePowerUpName(activeName);
        setPowerUpTimeLeft(Math.ceil(activeTimer));

        // 6. Update Inspector Rehan Distance Dynamics
        // Natural gradual recovery of distance if running clean (pulling ahead)
        // If boost is active, Rehan falls far behind!
        if (eng.activeBoost) {
          eng.rehanDistance = Math.min(100, eng.rehanDistance + dt * 25);
        } else {
          eng.rehanDistance = Math.min(95, eng.rehanDistance + dt * 2.5);
        }

        // Check if Rehan catches you (rehanDistance <= 0)
        if (eng.rehanDistance <= 2) {
          triggerGameOver('Inspector Rehan caught up to you!');
        }

        // 7. Move Objects Towards Player (Decreasing Z)
        const moveDist = eng.gameSpeed * dt;
        eng.distanceTraveled += moveDist;

        // Score accrual
        const scoreMultiplier = (eng.active2x ? 2 : 1) * (eng.activeBoost ? 1.5 : 1);
        eng.scoreVal += dt * 30 * scoreMultiplier;
        setScore(Math.floor(eng.scoreVal));

        // Spawn next obstacle if needed
        eng.nextObstacleZ -= moveDist;
        if (eng.nextObstacleZ <= 0) {
          spawnObstacleBatch(650);
          eng.nextObstacleZ = 200 + Math.random() * 120;
        }

        // Update Obstacles & Collision Check
        const PLAYER_Z = 70; // Player's fixed camera Z
        for (let i = eng.obstacles.length - 1; i >= 0; i--) {
          const obs = eng.obstacles[i];
          obs.z -= moveDist;

          // Collision detection
          // Object is at player plane: z around 50 to 90
          if (obs.z >= 45 && obs.z <= 95) {
            // Check lane alignment (smooth player lane within 0.45 of obstacle lane)
            const laneDiff = Math.abs(eng.playerLaneSmooth - obs.lane);
            if (laneDiff < 0.5) {
              // Now check obstacle vertical bypass
              let avoided = false;

              if (obs.type === 'barrier_low') {
                // Low hurdle: avoided if jumping high enough (playerY > 25)
                if (eng.playerY > 28) avoided = true;
              } else if (obs.type === 'barrier_high') {
                // High scaffold: avoided if sliding (player crouching)
                if (eng.isSliding) avoided = true;
              }

              if (!avoided && !obs.passed) {
                // Collision happened!
                if (eng.activeShield) {
                  // Shield protects!
                  eng.activeShield = false;
                  obs.passed = true;
                  sounds.playCrash();
                  addParticleBurst(rect.width / 2, rect.height * 0.7, '#3B82F6', 20);
                } else {
                  // Stumble or Game Over!
                  // If train or police car, instant crash
                  if (obs.type === 'train' || obs.type === 'police_car') {
                    sounds.playCrash();
                    triggerGameOver(`Crashed into ${obs.type === 'train' ? 'Karachi Subway Train' : 'Police Cruiser'}!`);
                    return;
                  } else {
                    // Stumble on barrier: Rehan surges forward significantly!
                    obs.passed = true;
                    sounds.playCrash();
                    eng.rehanDistance = Math.max(0, eng.rehanDistance - 45);
                    setRehanAlertMessage('STUMBLED! Rehan is right behind you!');
                    sounds.playWhistle();

                    if (eng.rehanDistance <= 5) {
                      triggerGameOver('Rehan tackled you after the stumble!');
                      return;
                    }
                  }
                }
              }
            }
          }

          // Cleanup past obstacles
          if (obs.z < -20) {
            eng.obstacles.splice(i, 1);
          }
        }

        // Update Coins & Magnet Gathering
        for (let i = eng.coins.length - 1; i >= 0; i--) {
          const coin = eng.coins[i];
          coin.z -= moveDist;

          // Magnet Attraction
          const magnetRadius = (eng.activeMagnet ? 250 : 0) * character.magnetBonus;
          if (magnetRadius > 0) {
            const zDist = Math.abs(coin.z - PLAYER_Z);
            if (zDist < magnetRadius) {
              // Pull coin toward player lane and z
              coin.lane += (eng.playerLaneSmooth - coin.lane) * 0.18;
              coin.y += (eng.playerY - coin.y) * 0.18;
            }
          }

          // Collection check
          if (!coin.collected && Math.abs(coin.z - PLAYER_Z) < 32) {
            const laneDiff = Math.abs(eng.playerLaneSmooth - coin.lane);
            const heightDiff = Math.abs(eng.playerY - coin.y);

            if (laneDiff < 0.5 && heightDiff < 45) {
              coin.collected = true;
              eng.coinsEarned += 1;
              setRunCoins(eng.coinsEarned);
              sounds.playCoin();
              addParticleBurst(rect.width / 2, rect.height * 0.7, '#FBBF24', 8);
            }
          }

          // Cleanup
          if (coin.z < -20 || coin.collected) {
            eng.coins.splice(i, 1);
          }
        }

        // Update Power-ups
        for (let i = eng.powerUps.length - 1; i >= 0; i--) {
          const pu = eng.powerUps[i];
          pu.z -= moveDist;

          if (!pu.collected && Math.abs(pu.z - PLAYER_Z) < 35) {
            const laneDiff = Math.abs(eng.playerLaneSmooth - pu.lane);
            if (laneDiff < 0.55) {
              pu.collected = true;
              sounds.playPowerup();
              addParticleBurst(rect.width / 2, rect.height * 0.65, '#10B981', 18);

              // Apply effect
              if (pu.type === 'shield') {
                eng.activeShield = true;
                eng.shieldTimer = 10;
              } else if (pu.type === 'magnet') {
                eng.activeMagnet = true;
                eng.magnetTimer = 12;
              } else if (pu.type === 'boost') {
                eng.activeBoost = true;
                eng.boostTimer = 7;
              } else if (pu.type === '2x') {
                eng.active2x = true;
                eng.doubleTimer = 14;
              }
            }
          }

          if (pu.z < -20 || pu.collected) {
            eng.powerUps.splice(i, 1);
          }
        }

        // Update Particles
        for (let i = eng.particles.length - 1; i >= 0; i--) {
          const p = eng.particles[i];
          p.x += p.vx * dt;
          p.y += p.vy * dt;
          p.alpha -= dt / p.life;
          if (p.alpha <= 0) {
            eng.particles.splice(i, 1);
          }
        }

        setRehanProximity(Math.round(eng.rehanDistance));
      }

      // Render Scene
      drawRunnerScene({
        ctx,
        width: canvas.width,
        height: canvas.height,
        playerLane: eng.playerLaneSmooth,
        targetLane: eng.targetLane,
        playerY: eng.playerY,
        isJumping: eng.isJumping,
        isSliding: eng.isSliding,
        slideProgress: eng.slideTimer,
        character,
        obstacles: eng.obstacles,
        coins: eng.coins,
        powerUps: eng.powerUps,
        particles: eng.particles,
        rehanDistance: eng.rehanDistance,
        rehanLane: eng.rehanLane,
        gameTime: eng.gameTime,
        activeShield: eng.activeShield,
        activeMagnet: eng.activeMagnet,
        activeBoost: eng.activeBoost,
        activeMultiplier: eng.active2x,
      });

      animId = requestAnimationFrame(gameLoop);
    };

    animId = requestAnimationFrame(gameLoop);
    return () => cancelAnimationFrame(animId);
  }, [isPlaying, isGameOver, isPaused, character]);

  const triggerGameOver = (reason: string) => {
    setIsGameOver(true);
    setIsPlaying(false);
    setRehanAlertMessage(reason);

    const finalScore = Math.floor(engineRef.current.scoreVal);
    const earnedCoins = engineRef.current.coinsEarned;

    onAddCoins(earnedCoins);
    if (finalScore > highScore) {
      onUpdateHighScore(finalScore);
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 }
      });
    }
  };

  const toggleSound = () => {
    const next = !soundMuted;
    setSoundMuted(next);
    sounds.setSoundEnabled(!next);
  };

  return (
    <div className="relative w-full h-full flex flex-col items-center justify-center bg-slate-950 select-none overflow-hidden touch-none font-['Fredoka',sans-serif]">
      {/* Canvas Viewport */}
      <canvas
        ref={canvasRef}
        onTouchStart={handleTouchStart}
        onTouchEnd={handleTouchEnd}
        className="w-full h-full block cursor-pointer"
      />

      {/* TOP HUD BAR */}
      <div className="absolute top-0 left-0 right-0 p-3 sm:p-4 flex items-center justify-between pointer-events-none z-20">
        {/* Left: Score & High Score */}
        <div className="flex flex-col gap-1">
          <div className="bg-slate-900/85 backdrop-blur-md px-3.5 py-1.5 rounded-full border border-slate-700/60 shadow-lg flex items-center gap-2">
            <Trophy className="w-4 h-4 text-amber-400" />
            <span className="text-white text-xs sm:text-sm font-black tracking-wider">
              {score.toLocaleString()} <span className="text-amber-400 font-semibold text-xs">PTS</span>
            </span>
            {score > highScore && highScore > 0 && (
              <span className="bg-red-500 text-white text-[10px] font-bold px-1.5 py-0.5 rounded-full animate-pulse">
                NEW BEST!
              </span>
            )}
          </div>

          <div className="bg-slate-900/85 backdrop-blur-md px-3 py-1 rounded-full border border-slate-700/60 shadow-lg flex items-center gap-2 w-max">
            <span className="text-yellow-400 text-sm">🪙</span>
            <span className="text-amber-300 text-xs sm:text-sm font-bold">
              {runCoins}
            </span>
          </div>
        </div>

        {/* Center: Rehan Proximity Meter */}
        {isPlaying && !isGameOver && (
          <div className="flex flex-col items-center bg-slate-900/80 backdrop-blur-md px-3 py-1.5 rounded-2xl border border-red-500/40 shadow-xl min-w-[130px] sm:min-w-[170px]">
            <div className="flex items-center gap-1.5 text-[11px] font-bold text-red-400 uppercase tracking-wide">
              <span>🚨 Rehan Alert</span>
              {rehanProximity < 35 && <span className="animate-ping text-[10px] text-red-500">●</span>}
            </div>
            {/* Health/Distance Bar */}
            <div className="w-full h-2.5 bg-slate-800 rounded-full mt-1 overflow-hidden border border-slate-700/60 relative">
              <div
                className={`h-full transition-all duration-200 rounded-full ${
                  rehanProximity > 60
                    ? 'bg-emerald-500'
                    : rehanProximity > 30
                    ? 'bg-amber-500'
                    : 'bg-red-600 animate-pulse'
                }`}
                style={{ width: `${Math.min(100, Math.max(5, rehanProximity))}%` }}
              />
            </div>
            <span className="text-[10px] text-slate-300 mt-0.5 font-semibold">
              {rehanProximity < 30 ? 'DANGER: HE IS REACHING!' : 'KEEP SPRINTING'}
            </span>
          </div>
        )}

        {/* Right: Quick Action Controls */}
        <div className="flex items-center gap-2 pointer-events-auto">
          {/* Character Badge */}
          <button
            onClick={onOpenSelectCharacter}
            className="flex items-center gap-1.5 bg-slate-900/90 hover:bg-slate-800 text-white px-2.5 py-1.5 rounded-xl border border-slate-700 transition active:scale-95 shadow-lg"
            title="Switch Character"
          >
            <span className="text-base">{character.avatarEmoji}</span>
            <span className="text-xs font-bold hidden sm:inline">{character.name}</span>
            <Users className="w-3.5 h-3.5 text-slate-400 sm:hidden" />
          </button>

          {/* Sound Toggle */}
          <button
            onClick={toggleSound}
            className="p-2 bg-slate-900/90 hover:bg-slate-800 text-slate-300 rounded-xl border border-slate-700 active:scale-95 transition shadow-lg"
          >
            {soundMuted ? <VolumeX className="w-4 h-4 text-red-400" /> : <Volume2 className="w-4 h-4 text-emerald-400" />}
          </button>
        </div>
      </div>

      {/* ACTIVE POWER-UP NOTIFICATION */}
      {activePowerUpName && isPlaying && !isGameOver && (
        <div className="absolute top-20 left-1/2 -translate-x-1/2 bg-indigo-600/90 border border-indigo-400/60 text-white px-4 py-1.5 rounded-full shadow-2xl flex items-center gap-2 backdrop-blur-md animate-bounce z-20">
          <Zap className="w-4 h-4 text-yellow-300" />
          <span className="text-xs sm:text-sm font-bold">{activePowerUpName}</span>
          <span className="bg-black/30 px-1.5 py-0.5 rounded-full text-xs font-mono font-bold text-yellow-200">
            {powerUpTimeLeft}s
          </span>
        </div>
      )}

      {/* START SCREEN OVERLAY */}
      {!isPlaying && !isGameOver && (
        <div className="absolute inset-0 bg-slate-950/80 backdrop-blur-md flex flex-col items-center justify-center p-4 z-30 text-center animate-fadeIn">
          <div className="max-w-md w-full bg-slate-900/95 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl flex flex-col items-center relative overflow-hidden">
            {/* Glowing Accent Top */}
            <div className="absolute top-0 left-0 right-0 h-2 bg-gradient-to-r from-blue-500 via-emerald-500 to-amber-500" />

            {/* Official Rehan Chase Logo */}
            <img
              src="/images/rehan-chase-logo.png"
              alt="Rehan Chase - Run Dodge Survive"
              className="w-44 h-44 sm:w-56 sm:h-56 object-contain drop-shadow-[0_0_25px_rgba(250,204,21,0.35)] animate-fadeIn"
            />

            <p className="text-slate-400 text-xs sm:text-sm mt-2 max-w-xs">
              Help <span className="text-blue-400 font-bold">Hamza</span>, <span className="text-emerald-400 font-bold">Huzaifa</span>, and <span className="text-amber-400 font-bold">Muaviya</span> escape Inspector Rehan!
            </p>

            {/* Selected Runner Preview */}
            <div
              onClick={onOpenSelectCharacter}
              className="mt-5 w-full bg-slate-800/80 hover:bg-slate-800 border border-slate-700/80 rounded-2xl p-3 flex items-center justify-between cursor-pointer transition active:scale-[0.98]"
            >
              <div className="flex items-center gap-3">
                <div
                  className="w-12 h-12 rounded-xl flex items-center justify-center text-2xl shadow-inner border border-white/20"
                  style={{ backgroundColor: character.color }}
                >
                  {character.avatarEmoji}
                </div>
                <div className="text-left">
                  <div className="flex items-center gap-1.5">
                    <span className="text-white font-bold text-sm sm:text-base">{character.name}</span>
                    <span className="text-[10px] bg-slate-700 text-slate-300 px-1.5 py-0.5 rounded-md font-semibold">
                      {character.role}
                    </span>
                  </div>
                  <p className="text-slate-400 text-xs italic">{character.nickname}</p>
                </div>
              </div>
              <div className="text-xs text-blue-400 font-bold flex items-center gap-1">
                Change ❯
              </div>
            </div>

            {/* Controls Guide */}
            <div className="mt-5 grid grid-cols-2 gap-2 w-full text-[11px] text-slate-300">
              <div className="bg-slate-800/60 p-2 rounded-xl border border-slate-700/50 flex items-center gap-2">
                <div className="flex gap-1">
                  <span className="bg-slate-700 px-1.5 py-0.5 rounded font-mono font-bold text-white">←</span>
                  <span className="bg-slate-700 px-1.5 py-0.5 rounded font-mono font-bold text-white">→</span>
                </div>
                <span>Swipe/Key: Change Lane</span>
              </div>
              <div className="bg-slate-800/60 p-2 rounded-xl border border-slate-700/50 flex items-center gap-2">
                <span className="bg-slate-700 px-1.5 py-0.5 rounded font-mono font-bold text-white">↑</span>
                <span>Swipe Up / Jump Hurdle</span>
              </div>
              <div className="bg-slate-800/60 p-2 rounded-xl border border-slate-700/50 flex items-center gap-2">
                <span className="bg-slate-700 px-1.5 py-0.5 rounded font-mono font-bold text-white">↓</span>
                <span>Swipe Down / Slide Barrier</span>
              </div>
              <div className="bg-slate-800/60 p-2 rounded-xl border border-slate-700/50 flex items-center gap-2">
                <span className="text-amber-400 font-bold">🚨</span>
                <span>Don't let Rehan catch you!</span>
              </div>
            </div>

            {/* Play Button */}
            <button
              onClick={startGame}
              className="mt-6 w-full py-4 bg-gradient-to-r from-emerald-500 to-green-600 hover:from-emerald-400 hover:to-green-500 text-white font-extrabold text-lg sm:text-xl rounded-2xl shadow-xl shadow-green-950/60 border border-green-400/40 active:scale-95 transition flex items-center justify-center gap-2 group font-['Bungee',sans-serif]"
            >
              <Play className="w-5 h-5 fill-white group-hover:scale-110 transition" />
              PLAY NOW
            </button>
          </div>
        </div>
      )}

      {/* GAME OVER SCREEN OVERLAY */}
      {isGameOver && (
        <div className="absolute inset-0 bg-slate-950/85 backdrop-blur-md flex flex-col items-center justify-center p-4 z-40 text-center animate-fadeIn">
          <div className="max-w-md w-full bg-slate-900 border border-red-900/60 rounded-3xl p-6 sm:p-8 shadow-2xl flex flex-col items-center relative overflow-hidden">
            {/* Official Rehan Chase Logo */}
            <img
              src="/images/rehan-chase-logo.png"
              alt="Rehan Chase - Run Dodge Survive"
              className="w-24 h-24 sm:w-28 sm:h-28 object-contain drop-shadow-[0_0_18px_rgba(220,38,38,0.4)] mb-1"
            />

            <h2 className="text-2xl sm:text-3xl font-black text-red-500 font-['Bungee',sans-serif]">
              BUSTED!
            </h2>
            <p className="text-slate-300 text-sm mt-1">{rehanAlertMessage}</p>

            {/* Results Box */}
            <div className="my-5 w-full bg-slate-800/80 border border-slate-700/80 rounded-2xl p-4 grid grid-cols-2 gap-4 text-center">
              <div>
                <span className="text-slate-400 text-xs font-semibold block">FINAL SCORE</span>
                <span className="text-2xl sm:text-3xl font-black text-white">{score.toLocaleString()}</span>
              </div>
              <div>
                <span className="text-slate-400 text-xs font-semibold block">COINS COLLECTED</span>
                <span className="text-2xl sm:text-3xl font-black text-amber-400 flex items-center justify-center gap-1">
                  🪙 +{runCoins}
                </span>
              </div>
            </div>

            {/* Highscore notification */}
            {score >= highScore && score > 0 && (
              <div className="w-full bg-amber-500/20 border border-amber-500/40 rounded-xl p-2.5 mb-5 flex items-center justify-center gap-2 text-amber-300 font-bold text-xs">
                <Sparkles className="w-4 h-4" />
                <span>NEW ALL-TIME RECORD!</span>
              </div>
            )}

            {/* Buttons */}
            <div className="flex flex-col sm:flex-row gap-3 w-full">
              <button
                onClick={startGame}
                className="flex-1 py-3.5 bg-gradient-to-r from-emerald-500 to-green-600 hover:from-emerald-400 hover:to-green-500 text-white font-black text-base rounded-2xl shadow-lg active:scale-95 transition flex items-center justify-center gap-2 font-['Bungee',sans-serif]"
              >
                <RotateCcw className="w-4 h-4" />
                TRY AGAIN
              </button>

              <button
                onClick={onOpenSelectCharacter}
                className="py-3.5 px-4 bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-sm rounded-2xl border border-slate-700 active:scale-95 transition flex items-center justify-center gap-2"
              >
                <Users className="w-4 h-4" />
                Runner
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MOBILE ONSCREEN TOUCH CONTROLS (Floating thumb buttons for accessibility) */}
      {isPlaying && !isGameOver && (
        <div className="absolute bottom-4 left-0 right-0 px-4 flex items-center justify-between pointer-events-none z-20">
          {/* Left/Right Thumb steering */}
          <div className="flex gap-3 pointer-events-auto">
            <button
              onClick={moveLeft}
              className="w-14 h-14 bg-slate-900/80 active:bg-blue-600 text-white rounded-2xl border border-slate-700 backdrop-blur-md flex items-center justify-center shadow-lg active:scale-90 transition"
              aria-label="Move Left"
            >
              <ArrowLeft className="w-7 h-7" />
            </button>
            <button
              onClick={moveRight}
              className="w-14 h-14 bg-slate-900/80 active:bg-blue-600 text-white rounded-2xl border border-slate-700 backdrop-blur-md flex items-center justify-center shadow-lg active:scale-90 transition"
              aria-label="Move Right"
            >
              <ArrowRight className="w-7 h-7" />
            </button>
          </div>

          {/* Jump/Slide Thumb triggers */}
          <div className="flex gap-3 pointer-events-auto">
            <button
              onClick={slide}
              className="w-14 h-14 bg-slate-900/80 active:bg-amber-600 text-white rounded-2xl border border-slate-700 backdrop-blur-md flex items-center justify-center shadow-lg active:scale-90 transition"
              aria-label="Slide Down"
            >
              <ArrowDown className="w-7 h-7" />
            </button>
            <button
              onClick={jump}
              className="w-14 h-14 bg-slate-900/80 active:bg-emerald-600 text-white rounded-2xl border border-slate-700 backdrop-blur-md flex items-center justify-center shadow-lg active:scale-90 transition"
              aria-label="Jump Up"
            >
              <ArrowUp className="w-7 h-7" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
