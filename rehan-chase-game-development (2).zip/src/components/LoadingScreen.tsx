import { useEffect, useState } from 'react';

interface LoadingScreenProps {
  onComplete: () => void;
}

export const LoadingScreen: React.FC<LoadingScreenProps> = ({ onComplete }) => {
  const [progress, setProgress] = useState<number>(0);

  useEffect(() => {
    // Preload the logo image, then run the progress bar
    const img = new Image();
    img.src = '/images/rehan-chase-logo.png';

    let raf: number;
    const start = Date.now();
    const DURATION = 1900; // ms

    const tick = () => {
      const elapsed = Date.now() - start;
      const pct = Math.min(100, Math.round((elapsed / DURATION) * 100));
      setProgress(pct);
      if (pct >= 100) {
        setTimeout(onComplete, 250);
      } else {
        raf = requestAnimationFrame(tick);
      }
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [onComplete]);

  return (
    <div className="fixed inset-0 z-[100] flex flex-col items-center justify-center bg-slate-950 px-6 font-['Fredoka',sans-serif] overflow-hidden">
      {/* Ambient glow */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(250,204,21,0.12),transparent_60%)]" />

      {/* Official Rehan Chase Logo */}
      <img
        src="/images/rehan-chase-logo.png"
        alt="Rehan Chase - Run Dodge Survive"
        className="w-64 h-64 sm:w-72 sm:h-72 object-contain drop-shadow-[0_0_35px_rgba(250,204,21,0.35)] animate-fadeIn relative z-10"
      />

      {/* Progress Bar */}
      <div className="w-full max-w-xs mt-8 relative z-10">
        <div className="h-3 w-full bg-slate-800 rounded-full overflow-hidden border border-slate-700/60">
          <div
            className="h-full bg-gradient-to-r from-amber-400 via-orange-500 to-blue-500 rounded-full transition-all duration-150 ease-out"
            style={{ width: `${progress}%` }}
          />
        </div>
        <div className="flex items-center justify-between mt-2">
          <span className="text-slate-400 text-xs font-semibold tracking-wide animate-pulse">
            LOADING KARACHI SUBWAY...
          </span>
          <span className="text-amber-400 text-xs font-black font-mono">{progress}%</span>
        </div>
      </div>
    </div>
  );
};
